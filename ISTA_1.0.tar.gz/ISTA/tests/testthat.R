library(testthat)
library(ISTA)

test_check("ISTA")
